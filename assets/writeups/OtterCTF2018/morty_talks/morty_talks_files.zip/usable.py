import pyshark

pcap = pyshark.FileCapture('Morty_Talks.pcap', display_filter='tcp.port == 62023')

key = []
traffic = [p for p in pcap][3:-3]

single_char = traffic[1::2]
encypted = traffic[::2]

key.append(encypted[0].data.data.binary_value[0])

odd_key = []
for s in single_char:
	single_val = s.data.data.binary_value[0]
	odd_key.append(single_val)

p = 0
even_key = []
for e in encypted:
	single_val = e.data.data.binary_value[p]
	even_key.append(single_val)

KEY = []
for i in range(len(even_key)):
	KEY.append(even_key[i])
	KEY.append(odd_key[i])

# EVEN = MrySih(ocdb utnRiad1)\x96Rc\' 4ya-l rnsnwoi rqetydagdit iksmsdetrs ot sago i u ei aiydsrse.H sotnrlcatt olwRc\' ln,adh fe nsu ruaie yteuotoo n oal usinbemtosRc sst fx iutos h anMryteeioe olwi eerdt ste"otetMry yRc u ohscuae hc eryeeyohrMr
# ODD  = ot mt vie yJsi oln[]  iks1-erodgado h sfeunl rge noRc' iavnue.Mryi  odkdbth sesl itesd ei fe eutn oflo ikspas n eotned ptamtzdb h nrhdxadmrlyqetoal ehd ikue o'i'stain.Temi ot h psdsflo srfre oa h Mris ot"b ikdet i org,wihnal vr te ot ak u

FINAL_KEY = [ ord(i) for i in 'Morty Smith (voiced by Justin Roiland[1]) \x96 Rick\'s 14-year-old grandson who is frequently dragged into Rick\'s misadventures. Morty is a good kid but he is easily distressed. He is often reluctant to follow Rick\'s plans, and he often ends up traumatized by the unorthodox and morally questionable methods Rick uses to \'fix\' situations. The main Morty the episodes follow is referred to as the "Mortiest Morty" by Rick due to his courage, which nearly every other Morty lacks due to their main use being makeshift cloaking device']
TOT = len(encypted)
p=0
for i in range(TOT):
	enc = encypted[i].data.data.binary_value[1:]
	dec = ''.join( [ chr(enc[k] ^ FINAL_KEY[k % (p+1)]) for k in range(len(enc)) ] )
	print(i, dec)
	p+=2
	